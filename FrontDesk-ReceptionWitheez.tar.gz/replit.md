# FrontDesk.AI - AI Receptionist Application

## Overview

FrontDesk.AI is a 24/7 autonomous AI-powered receptionist service designed to handle visitor check-ins, staff notifications, FAQ responses, and appointment management. The application provides a conversational chat interface for visitors to interact with an AI assistant that can integrate with business tools like Slack and calendar systems. The solution can be deployed as a lobby kiosk or website widget, offering businesses a scalable, always-available front desk solution.

## User Preferences

Preferred communication style: Simple, everyday language.

## Project Status (Nov 8, 2025)

**Current State**: Production-ready frontend running on Vite + React + Bun. Dark-themed chat interface fully functional and awaiting backend API integration.

**Migration Notes**: Successfully migrated from Next.js to Vite + React due to segmentation faults in the Next.js environment. Bun runtime proved stable and performant.

## System Architecture

### Frontend Architecture

**Technology Stack**: 
- React 18 with TypeScript for type-safe component development
- Vite 6 as the build tool and development server (replacing Next.js)
- Bun runtime for the dev server (port 5000)
- Tailwind CSS 3.x for utility-first styling

**Rationale**: Vite offers faster development builds and hot module replacement compared to traditional bundlers. The Bun runtime eliminates the segmentation faults that plagued the Next.js setup. React 18 provides the latest features including concurrent rendering capabilities.

**Component Structure**: 
- `App.tsx` - Main landing page with branding and feature explanations
- `ReceptionistChat.tsx` - Interactive chat widget with message history, auto-scroll, and loading states
- Clean separation of concerns with modular component design

**Styling Solution**: Tailwind CSS provides utility-first styling with a custom dark theme:
- Background: zinc-950 (deep dark)
- Primary accent: emerald-400 (bright green)
- Responsive design with mobile-first breakpoints
- Professional, modern aesthetic suitable for business environments

**State Management**: Local component state using React hooks (useState, useEffect, useRef). No global state management library needed for current scope - keeps the architecture lean and maintainable.

**Animation Library**: Framer Motion included as a dependency for potential future UI animations and transitions.

### Backend Integration

**API Communication**: 
- Axios HTTP client for robust API requests
- Backend endpoint: `POST /chat`
- Base URL configured via environment variable `VITE_API_BASE` (default: `http://localhost:8000`)

**API Contract**:
```json
{
  "message": "user's message text",
  "tenant_id": "demo",
  "conversation": [
    {"id": "1", "role": "assistant", "content": "welcome message"},
    {"id": "2", "role": "user", "content": "user message"}
  ]
}
```

**Conversation Flow**: 
- Frontend maintains complete message history client-side
- Filters out the initial welcome message before sending to API
- Backend processes requests (presumably using GPT or similar AI models)
- Response is appended to the conversation history

**Message Structure**: Messages follow a standardized format compatible with common chat completion APIs:
- `id` - Unique message identifier
- `role` - Either "user" or "assistant"
- `content` - Message text content

### UI/UX Design Patterns

**Chat Interface**: 
- Conversational UI with distinct message bubbles for user and assistant
- Auto-scrolling to latest messages for seamless UX
- Loading states with disabled input during API calls
- Welcome message to guide initial user interaction

**Form Handling**: 
- Standard form submission with Enter key support
- Validation prevents empty messages
- Duplicate submission prevention during loading states

**Accessibility**: 
- Semantic HTML structure
- Headless UI components for accessible interactive elements
- Proper ARIA labels and roles

## External Dependencies

### Third-Party Libraries

**UI Components**: 
- @headlessui/react (v2.2.9) - Unstyled, accessible UI primitives
- lucide-react (v0.553.0) - Modern icon library with React components

**HTTP Client**:
- axios (v1.13.2) - Promise-based HTTP client with interceptor support

**Animation**:
- framer-motion (v12.23.24) - Production-ready motion library for React

### Backend Services

**AI Processing API** (Expected): 
- Backend service running on port 8000
- Handles chat completion requests
- Expected integrations:
  - GPT or similar LLM for natural language understanding
  - Custom business logic for receptionist workflows
  - Slack API for staff notifications
  - Calendar services for appointment management
  - Custom CRM/visitor management systems

### Development Tools

**Build System**:
- Vite (v6.0.7) - Next-generation frontend tooling
- TypeScript (v5.7.3) - Static type checking
- PostCSS & Autoprefixer - CSS processing pipeline
- Bun - Fast JavaScript runtime and package manager

**Code Quality**:
- ESLint (v9.18.0) with React-specific plugins
- TypeScript strict mode enabled
- Hot module replacement for rapid development

### Configuration Files

**TypeScript Configuration**:
- `tsconfig.json` - Main app TypeScript config with strict mode
- `tsconfig.node.json` - Node-compatible config for build tools
- `src/vite-env.d.ts` - Vite environment variable type definitions

**Build Configuration**:
- `vite.config.ts` - Vite server config (port 5000, host 0.0.0.0, path aliases, preview server settings)
- `tailwind.config.ts` - Tailwind CSS customization
- `postcss.config.mjs` - PostCSS plugins configuration

**Deployment Configuration**:
- Production build: `bun run build` - Compiles TypeScript and creates optimized bundle
- Production server: `bun run preview` - Serves production build with allowedHosts enabled
- Deployment target: `autoscale` - Scales automatically based on traffic

**Environment Variables**:
- `.env.local` - Local environment configuration (VITE_API_BASE)
- Not committed to version control for security

## Development Workflow

**Start Development Server**:
```bash
bun run dev
```

**Important Notes**:
- Always use `bun run dev`, NOT `npm run dev` (npm causes segmentation faults)
- Server binds to `0.0.0.0:5000` for proper Replit webview access
- Hot module replacement enabled for instant feedback
- TypeScript errors checked in real-time

## Project Structure

```
src/
├── App.tsx                      # Main landing page component
├── components/
│   └── ReceptionistChat.tsx    # Chat widget component
├── main.tsx                     # Application entry point
├── index.css                    # Global styles and Tailwind imports
└── vite-env.d.ts               # Vite environment type definitions
```

## Recent Changes (Nov 8, 2025)

1. **Migration from Next.js to Vite** - Resolved persistent segmentation faults
2. **Switched to Bun runtime** - Improved stability and performance
3. **Fixed TypeScript configuration** - Eliminated all LSP diagnostics
4. **Cleaned up config files** - Removed Next.js artifacts, modernized Vite/Tailwind configs
5. **Verified zero runtime errors** - App runs cleanly with no console errors
6. **Configured production deployment** - Set up autoscale deployment with build and preview commands
7. **Fixed deployment host blocking** - Added allowedHosts configuration for Replit deployment domains

## Next Steps (Recommendations)

1. **Backend Integration** - Connect to FastAPI backend with GPT integration
2. **Real-time Features** - Consider WebSocket support for live notifications
3. **Authentication** - Add user/tenant authentication for multi-tenant support
4. **Deployment** - Publish to production with Replit's deployment tools
