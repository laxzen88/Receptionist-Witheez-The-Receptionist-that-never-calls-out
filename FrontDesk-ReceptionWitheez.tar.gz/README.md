# AI Receptionist Site

This is a Next.js project for an AI-powered receptionist service.

## Getting Started

First, run the development server:

```bash
npm run dev
```

Open your browser to see the result.

## Features

- Next.js 15 with App Router
- TypeScript
- Tailwind CSS
- Modern React 19

## Learn More

To learn more about Next.js, check out the [Next.js Documentation](https://nextjs.org/docs).
