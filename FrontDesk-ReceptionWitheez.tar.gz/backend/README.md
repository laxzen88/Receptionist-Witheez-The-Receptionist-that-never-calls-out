# FrontDesk.Ai-ReceptionistWitheez Backend

Secure FastAPI backend for the AI receptionist application.

## Security Features

### 1. Input Validation & Sanitization
- All inputs validated using Pydantic models
- HTML tag removal to prevent XSS attacks
- Length limits on all text fields
- Type checking on all request parameters

### 2. Rate Limiting
- **Chat endpoint**: 5 requests/minute per IP
- **Health endpoint**: 10 requests/minute per IP
- Prevents abuse and DoS attacks

### 3. Security Headers
- **X-Content-Type-Options**: Prevents MIME sniffing
- **X-Frame-Options**: Prevents clickjacking
- **X-XSS-Protection**: Browser XSS protection
- **HSTS**: Enforces HTTPS
- **Referrer-Policy**: Controls referrer information
- **Content-Security-Policy**: Restricts resource loading
- **Permissions-Policy**: Disables unnecessary browser features

### 4. CORS Configuration
- Configurable allowed origins
- **⚠️ PRODUCTION WARNING**: Set `ALLOWED_ORIGINS` environment variable to your specific frontend domain(s)
- Default `*` is for development only and should NOT be used in production

### 5. Error Handling
- Generic error messages to prevent information leakage
- Detailed logging for debugging (backend only)
- No stack traces exposed to clients

## Environment Variables

Required (stored in Replit Secrets):
- `SUPABASE_URL`: Your Supabase project URL
- `SUPABASE_SERVICE_KEY`: Your Supabase service role key

Optional:
- `ALLOWED_ORIGINS`: Comma-separated list of allowed origins (default: `*`)

## Production Deployment Checklist

Before deploying to production:

1. ✅ Set `ALLOWED_ORIGINS` to your specific frontend domain(s)
   ```
   ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
   ```

2. ✅ Review and adjust rate limiting based on expected traffic
   - Monitor actual usage patterns
   - Adjust limits in `app.py` if needed

3. ✅ Enable HTTPS/SSL (required for HSTS header to work)

4. ✅ Set up logging and monitoring for rate limit violations

5. ✅ Review and test all security headers in your production environment

6. ✅ Implement Row Level Security (RLS) policies in Supabase

## Running the Backend

```bash
cd backend
python app.py
```

The server will start on `http://0.0.0.0:8000`

## API Endpoints

- `GET /health` - Health check endpoint
- `POST /chat` - Chat endpoint for AI receptionist interactions
