import { useState, useEffect, useRef, FormEvent } from "react";
import DOMPurify from "dompurify";

type Role = "user" | "assistant";

interface Message {
  id: string;
  role: Role;
  content: string;
}

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";
const MAX_MESSAGE_LENGTH = 500;
const RATE_LIMIT_WINDOW = 10000;
const MAX_REQUESTS_PER_WINDOW = 5;

const ReceptionistChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hey, welcome in 👋 I'm your AI front desk. Who are you here to see, or what can I help you with today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const requestTimestamps = useRef<number[]>([]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const checkRateLimit = (): boolean => {
    const now = Date.now();
    requestTimestamps.current = requestTimestamps.current.filter(
      (timestamp) => now - timestamp < RATE_LIMIT_WINDOW
    );

    if (requestTimestamps.current.length >= MAX_REQUESTS_PER_WINDOW) {
      return false;
    }

    requestTimestamps.current.push(now);
    return true;
  };

  const sanitizeInput = (text: string): string => {
    return DOMPurify.sanitize(text, { ALLOWED_TAGS: [] }).trim();
  };

  const sendMessage = async (e: FormEvent) => {
    e.preventDefault();

    const trimmed = sanitizeInput(input);
    
    if (!trimmed || loading) return;

    if (trimmed.length > MAX_MESSAGE_LENGTH) {
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: `Message is too long. Please keep it under ${MAX_MESSAGE_LENGTH} characters.`,
      };
      setMessages((prev) => [...prev, errorMessage]);
      return;
    }

    if (!checkRateLimit()) {
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: "You're sending messages too quickly. Please wait a moment and try again.",
      };
      setMessages((prev) => [...prev, errorMessage]);
      return;
    }

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmed,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const conversation = messages
        .filter((m) => m.id !== "welcome")
        .map((m) => ({
          role: m.role,
          content: sanitizeInput(m.content),
        }))
        .concat({ role: "user", content: trimmed });

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      const res = await fetch(`${API_BASE}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          tenant_id: "demo",
          conversation,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        throw new Error("Failed to reach AI receptionist");
      }

      const data = await res.json();

      const assistantText: string = sanitizeInput(
        (data && (data.text || data.message || "")) ||
        "I had trouble responding just now. Please try again."
      );

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: assistantText,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: "I couldn't connect to the system right now. Please try again in a moment.",
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col max-w-md w-full h-[500px] rounded-3xl border border-zinc-800/60 bg-zinc-900/80 backdrop-blur-lg shadow-2xl overflow-hidden">
      <div className="px-4 py-3 border-b border-zinc-800/80 flex items-center gap-2">
        <div className="w-8 h-8 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 text-xl">
          ✺
        </div>
        <div className="flex flex-col leading-tight">
          <span className="text-sm font-semibold text-zinc-100">
            FrontDesk.Ai-ReceptionistWitheez
          </span>
          <span className="text-[10px] text-emerald-400">
            Online · Autonomous Receptionist
          </span>
        </div>
      </div>

      <div className="flex-1 px-3 py-3 space-y-2 overflow-y-auto text-sm">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex ${
              m.role === "user" ? "justify-end" : "justify-start"
            }`}
          >
            <div
              className={`max-w-[80%] px-3 py-2 rounded-2xl whitespace-pre-wrap ${
                m.role === "user"
                  ? "bg-emerald-500 text-zinc-950 rounded-br-sm"
                  : "bg-zinc-800/90 text-zinc-100 rounded-bl-sm"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="px-3 py-2 rounded-2xl bg-zinc-800/90 text-zinc-400 text-[11px] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce" />
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce [animation-delay:0.12s]" />
              <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce [animation-delay:0.24s]" />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={sendMessage}
        className="px-3 py-3 border-t border-zinc-800/80 flex items-center gap-2 bg-zinc-950/90"
      >
        <input
          type="text"
          className="flex-1 bg-zinc-900/90 border border-zinc-800/80 rounded-2xl px-3 py-2 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:ring-1 focus:ring-emerald-500/70 focus:border-emerald-500/50"
          placeholder="Tell me who you're here to see or what you need help with..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          maxLength={MAX_MESSAGE_LENGTH}
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-3 py-2 rounded-2xl text-xs font-semibold bg-emerald-500 text-zinc-950 hover:bg-emerald-400 disabled:opacity-40 disabled:cursor-not-allowed transition"
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default ReceptionistChat;
