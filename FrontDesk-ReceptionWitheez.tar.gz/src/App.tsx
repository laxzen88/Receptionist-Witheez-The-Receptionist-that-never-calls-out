import ReceptionistChat from './components/ReceptionistChat'

function App() {
  return (
    <main className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col items-center justify-center px-4">
      <div className="max-w-4xl w-full flex flex-col md:flex-row items-center gap-10">
        <div className="flex-1 space-y-4">
          <h1 className="text-3xl md:text-4xl font-semibold leading-tight">
            FrontDesk.Ai-ReceptionistWitheez
            <span className="block text-emerald-400 text-xl md:text-2xl">
              Your 24/7 autonomous receptionist.
            </span>
          </h1>
          <p className="text-sm text-zinc-400 max-w-md">
            Check in visitors, notify staff on Slack, answer FAQs, and manage
            appointments — all without a human sitting at the desk.
          </p>
          <ul className="text-xs text-zinc-500 space-y-1">
            <li>• Built on GPT & real integrations (Slack, calendar, more)</li>
            <li>• Custom brand voice for each business</li>
            <li>• Deployable as lobby kiosk or website widget</li>
          </ul>
        </div>
        <div className="flex-1 flex justify-center">
          <ReceptionistChat />
        </div>
      </div>
    </main>
  )
}

export default App
